# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import math
import torch
from collections.abc import Sequence

import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation
from isaaclab.envs import DirectRLEnv
from isaaclab.sim.spawners.from_files import GroundPlaneCfg, spawn_ground_plane
from isaaclab.utils.math import sample_uniform
from .last_brick_env_cfg import LastBrickEnvCfg


class LastBrickEnv(DirectRLEnv):
	cfg: LastBrickEnvCfg

	def __init__(self, cfg: LastBrickEnvCfg, render_mode: str | None = None, **kwargs):
		super().__init__(cfg, render_mode, **kwargs)


	def _setup_scene(self):
		# add ground plane
		spawn_ground_plane(prim_path="/World/ground", cfg=GroundPlaneCfg())
		# clone and replicate
		self.scene.clone_environments(copy_from_source=False)
		# add lights
		light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))
		light_cfg.func("/World/Light", light_cfg)
		# brick env
		brick_env_cfg = sim_utils.UsdFileCfg(
			usd_path="file:/root/IsaacLab/source/isaaclab_assets/data/Env/Brick1.usd",
			activate_contact_sensors=False,
			scale=(1.0, 1.0, 1.0),
			collision_props=sim_utils.CollisionPropertiesCfg(),
		)
		brick_env_cfg.func("{ENV_REGEX_NS}/brick", brick_env_cfg)
		
		# Last brick
		last_brick_cfg = RigidObjectCfg(
			init_state=RigidObjectCfg.InitialStateCfg(
				pos=(-0.38952, 2.11861, 2.40992),
				rot=(0.1072, 0.0, 0.0, -0.9942),
			),
			spawn=sim_utils.UsdFileCfg(
				usd_path="file:/root/IsaacLab/source/isaaclab_assets/data/Env/last_brick.usd",
				activate_contact_sensors=False,
				scale=(1.09, 1.09, 1.0),
				collision_props=sim_utils.CollisionPropertiesCfg(),
				rigid_props=sim_utils.RigidBodyPropertiesCfg(),
			)
		)
		last_brick_cfg.func("{ENV_REGEX_NS}/last_brick", last_brick_cfg)

	def _pre_physics_step(self, actions: torch.Tensor) -> None:
		self.actions = actions.clone()

	def _apply_action(self) -> None:
		self.last_brick.set_external_force_and_torque(forces=self.actions, torques =  torch.zeros(0,3))	

	def _get_observations(self) -> dict:
		# TODO Observations	
		observations = 

		return observations

	def _get_rewards(self) -> torch.Tensor:
		# TODO Total rewards with weights
		total_reward = 

		return total_reward

	def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:

		out_of_bounds = 
		time_out = self.episode_length_buf >= self.max_episode_length - 1

		return out_of_bounds, time_out

	def _reset_idx(self, env_ids: Sequence[int] | None):
		if env_ids is None:
			env_ids = self.robot._ALL_INDICES
		super()._reset_idx(env_ids)


@torch.jit.script
def compute_rewards(
	#TODO rewards
):
	# TODO Define rewards
	total_reward
	return total_reward
